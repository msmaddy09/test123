[![pipeline status](https://git.sys.cigna.com/cigna-terraform/aws/golden-vpc/badges/master/pipeline.svg)](https://git.sys.cigna.com/cigna-terraform/aws/golden-vpc/commits/master)  

# Cigna Golden VPC
Terraform module for standing up Cignatized AWS VPC

## Golden VPC DNS Resolver Association Fix
We are aware that teams use terraform in a variety of different methods, join [DNS Resolver Fix Mattermost channel](https://mm.sys.cigna.com/cloud-ops-guild/channels/dns-resolver-fix) for support and questions.

Associated Communication Confluence Page: [https://confluence.sys.cigna.com/pages/viewpage.action?pageId=382674813](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=382674813)

**01/29/2021: If you are experiencing Terraform state issues regarding DNS resolver rule associations, then please:**
1. Identify VPC that needs to be fixed and grab *vpc-id*
   - Example: `vpc-040ac20c57a86f437`
2. Locate var file for `terraform import` command (validate the path can be found from your terraform directory)
   - Example: `/dev.tfvars`
3. Run the `./bin/dns-resolver-fix.sh <vpc-id> <path-to-var-file>` with the two expected arguments from step 1 and step 2
   - Example command: `./bin/dns-resolver-fix.sh vpc-040ac20c57a86f437 dev.tfvars`
   - Note: If your aws-profile is not named `saml` pass a third variable to the script
     - Example command: `./bin/dns-resolver-fix.sh vpc-040ac20c57a86f437 dev.tfvars cvw-dev` 
4. Initialize your terraform backend
   - Example command: `terraform init -backend-config="bucket=MYACCOUNT-tfstate" -backend-config="dynamodb_table=terraform-lock"`
5. Set aws region environment variable for terraform
   - `export TF_VAR_aws_region=us-east-1`
6. Capture the output of shell script in step 1 and run the terraform commands printed in the output (`terraform state rm` and `terraform import`)
   
Sample Output from shell script (**DO NOT RUN THIS EXACT SAMPLE**):
```sh
terraform state rm module.cigna-golden-vpc.aws_route53_resolver_rule_association.cigna[0]
terraform state rm module.cigna-golden-vpc.aws_route53_resolver_rule_association.cignatest[0]
terraform state rm module.cigna-golden-vpc.aws_route53_resolver_rule_association.silver[0]
terraform state rm module.cigna-golden-vpc.aws_route53_resolver_rule_association.self[0]
terraform state rm module.cigna-golden-vpc.aws_route53_resolver_rule_association.openshift[0]
terraform import -var-file=./dev.tfvars module.cigna-golden-vpc.aws_route53_resolver_rule_association.cigna[0] rslvr-rrassoc-****
terraform import -var-file=./dev.tfvars module.cigna-golden-vpc.aws_route53_resolver_rule_association.cignatest[0] rslvr-rrassoc-****
terraform import -var-file=./dev.tfvars module.cigna-golden-vpc.aws_route53_resolver_rule_association.openshift[0] rslvr-rrassoc-****
terraform import -var-file=./dev.tfvars module.cigna-golden-vpc.aws_route53_resolver_rule_association.silver[0] rslvr-rrassoc-****
terraform import -var-file=./dev.tfvars module.cigna-golden-vpc.aws_route53_resolver_rule_association.self[0] rslvr-rrassoc-****
```
> Note: If you have additional *tfvars* that are used such as `common.tfvars`, you will need to pass `-var-file` flag again referencing those files.

**Example Command**
```sh
terraform import -var-file=./dev.tfvars -var-file=./common.tfvars module.cigna-golden-vpc.aws_route53_resolver_rule_association.cignatest[0] rslvr-rrassoc-****
```

5. Upgrade to golden-vpc `1.7.5` or higher.
   - Execute `terraform init`
   - Execute `terraform plan`
   - Execute `terraform apply`


## Supported Version
- Terraform: ```=> 0.12.31```
- AWS Provider:  ```=> 3.10.0```

## Overview
This Terraform module creates:
  - VPC
  - Dynamic # of subnets
    - VPC CIDR block is divided evenly amongst subnets
    - Each subnet placed in different AZ to ensure high availability
  - Security group
    - Allows all egress traffic (0.0.0.0/0), and all ingress from within Cigna (10.0.0.0/8)
  - CloudWatch log group w/ VPC flow log
    - Auto subscribe log group to centralized logging solution stream for all Prod VPCs
  - TGW Attachment Request (optional)
  - DNS Shared Resolvers for Below Domains
    - cigna.com
    - aws.cignacloud.com
    - cignatest.com
    - silver.com
  - VPC Endpoints
    - Supports both interface and gateway endpoints
    - Attach a policy configuration to a gateway endpoint (optional)
  - EKS configuration (optional)
    - Add cluster tags to vpc and subnets
    - Create additional subnets for pods
    - Setup NAT Gateway (optional)

## Dependencies
- Terraform Version >= 0.12.31
- Request a CIDR block from networking team.  Details on can be found [here](https://confluence.sys.cigna.com/display/BD/AWS+Account+Creation+and+VPN+Set+Up#AWSAccountCreationandVPNSetUp-Step1:GettingaCIDRBlock)

## Post Install
- If you need to access on prem resources not covered by the [Global FCR](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=267521115), submit custom FCR to enable firewall access.  See step 4 for more [details](https://confluence.sys.cigna.com/display/CLOUD/AWS+Getting+Started+Guide)
- Reach out to Enterprise Network Engineering to request that your TGW attachment be accepted [link](https://confluence.sys.cigna.com/pages/viewpage.action?pageId=271129462)

## Network Architecture
![Alt text](docs/arch-diagram-golden-vpc.png?raw=true "Title")  

## Inputs
See [examples/main/vpc.auto.tfvars](examples/main/vpc.auto.tfvars)

## Outputs
See [outputs.md](docs/outputs.md)

## Role Permissions Needed
- In all non sandbox accounts a policy exists called `GoldenVPCRequirements`
- Attach the above policy to your role to have all necessary permissions for deploying the Golden VPC

## EKS
- The eks-vpc module has been merged into golden-vpc for maintainablilty.  
- The minimum configuration required to enable EKS 
  - Uncomment the config block referenced in the bottom of [vpc.auto.tfvars](examples/main/vpc.auto.tfvars) 
  - service_interface_endpoints must contain at least 'ec2,logs,ecr.dkr,ecr.api'
    - If you intend to use ssm append the following to service_interface_endpoints: 'ssm,ec2messages,ssmmessages'
  - service_gateway_endpoints must contain 's3'
- For more info on EKS setup see [this readme](https://git.sys.cigna.com/aws_foundational/Kubernetes/eks-cluster-parent). 

## Gateway Endpoint Policy
- The option exists to add a specific policy to a gateway endpoint service.
- To add the policy add to *vpc.auto.tfvars* a map named *vpc_endpoint_policy_configs* with the endpoint name and policy to attach
- Example:
```hcl
vpc_endpoint_policy_configs = {
  dynamodb = <<POLICY
{ 
  "Version": "2008-10-17",
  "Statement": [
      {   
          "Action": "dynamodb:*",
          "Effect": "Allow",
          "Resource": [
            "arn:aws:dynamodb:us-east-1:120357612572:table/cigna-tf-lock-*",
            "arn:aws:dynamodb:us-east-1:120357612572:table/mytable"
          ],
          "Principal": "*"
      }
  ]
}
POLICY
  s3 = <<POLICY
{
    "Version": "2008-10-17",
    "Statement": [
        {
            "Action": "s3:*",
            "Effect": "Allow",
            "Resource": [
              "arn:aws:s3:::mybucket",
              "arn:aws:s3:::mybucket/*"
            ],
            "Principal": "*"
        }   
    ]   
}   
POLICY
} 
```

## Caveats
### Other regions
- For the most part the golden-vpc module can work in any region. The other regions need the following:
  - The region must have a transit gateway (networking team)
  - The region must have a central logging destination (splunk monitoring team)
  - The following SSM parameters must be present and/or created:
    - /Enterprise/CentralLoggingDestinationArn
    - /Enterprise/TgwId

## Additional Notes
- For the account specific domain (*awsaccountname*.aws.cignacloud.com) to be set in DHCP options both `private_zone_enabled` and `reverse_lookup_enabled` must be set to `true`
- VPC Flow Logs can be viewed in Cloud Watch -> Logs -> Log Groups under the name
  - `name_prefix`-golden-vpc-`vpcId`

## Usage
- Copy example of module import from `examples/main/*`
  - No other files are required from this repository due to refereince in `main.tf`
- Update `vpc.auto.tfvars` file with required values
- `terraform init -backend-config="bucket=<bucket-name>" -backend-config="key=<sdlc-env>/golden-vpc/terraform.tfstate" -backend-config="region=<bucket-region>" -backend-config="profile=saml" -backend=true`
- `terraform plan`
- `terraform apply -auto-approve`

