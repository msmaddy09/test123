```hcl
gateway_endpoints = [
  {
    "cidr_blocks" = [
      "54.231.0.0/17",
      "52.216.0.0/15",
    ]
    "dns_entry" = []
    "id" = "vpce-0294d96f21227168a"
    "network_interface_ids" = []
    "owner_id" = "120357612572"
    "policy" = "{\"Statement\":[{\"Action\":\"s3:*\",\"Effect\":\"Allow\",\"Principal\":\"*\",\"Resource\":[\"arn:aws:s3:::da-datastore*\",\"arn:aws:s3:::da-datastore*/*\",\"arn:aws:s3:::cds-*\",\"arn:aws:s3:::cds-*/*\",\"arn:aws:s3:::us-east-1.elasticmapreduce\",\"arn:aws:s3:::us-east-1.elasticmapreduce/*\"]}],\"Version\":\"2008-10-17\"}"
    "prefix_list_id" = "pl-63a5400a"
    "private_dns_enabled" = false
    "requester_managed" = false
    "route_table_ids" = [
      "rtb-0dbbc61053fb1b05b",
    ]
    "security_group_ids" = []
    "service_name" = "com.amazonaws.us-east-1.s3"
    "state" = "available"
    "subnet_ids" = []
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-s3-endpoint"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_endpoint_type" = "Gateway"
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
  {
    "cidr_blocks" = [
      "52.94.0.0/22",
      "52.119.224.0/20",
    ]
    "dns_entry" = []
    "id" = "vpce-0a0f4d7aa529fe341"
    "network_interface_ids" = []
    "owner_id" = "120357612572"
    "policy" = "{\"Statement\":[{\"Action\":\"*\",\"Effect\":\"Allow\",\"Principal\":\"*\",\"Resource\":\"*\"}],\"Version\":\"2008-10-17\"}"
    "prefix_list_id" = "pl-02cd2c6b"
    "private_dns_enabled" = false
    "requester_managed" = false
    "route_table_ids" = [
      "rtb-0dbbc61053fb1b05b",
    ]
    "security_group_ids" = []
    "service_name" = "com.amazonaws.us-east-1.dynamodb"
    "state" = "available"
    "subnet_ids" = []
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-dynamodb-endpoint"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_endpoint_type" = "Gateway"
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
]
interface_endpoints = [
  {
    "cidr_blocks" = []
    "dns_entry" = [
      {
        "dns_name" = "vpce-04fd215af4e83bd10-a44fi3g6.ec2.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "vpce-04fd215af4e83bd10-a44fi3g6-us-east-1b.ec2.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "vpce-04fd215af4e83bd10-a44fi3g6-us-east-1a.ec2.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "ec2.us-east-1.amazonaws.com"
        "hosted_zone_id" = "Z09149851QJIO4I9I8QJ5"
      },
    ]
    "id" = "vpce-04fd215af4e83bd10"
    "network_interface_ids" = [
      "eni-0009ca09900a5958f",
      "eni-0cec0049894ed66c0",
    ]
    "owner_id" = "120357612572"
    "policy" = "{\"Statement\":[{\"Action\":\"*\",\"Effect\":\"Allow\",\"Principal\":\"*\",\"Resource\":\"*\"}]}"
    "private_dns_enabled" = true
    "requester_managed" = false
    "route_table_ids" = []
    "security_group_ids" = [
      "sg-04fd55d1e6c4d8706",
    ]
    "service_name" = "com.amazonaws.us-east-1.ec2"
    "state" = "available"
    "subnet_ids" = [
      "subnet-0cf35ab1f22c912a4",
      "subnet-0eafa2ee962c64211",
    ]
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-ec2-endpoint"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_endpoint_type" = "Interface"
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
  {
    "cidr_blocks" = []
    "dns_entry" = [
      {
        "dns_name" = "vpce-0eea94c8bb5fd11c5-72odcdte.logs.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "vpce-0eea94c8bb5fd11c5-72odcdte-us-east-1b.logs.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "vpce-0eea94c8bb5fd11c5-72odcdte-us-east-1a.logs.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "logs.us-east-1.amazonaws.com"
        "hosted_zone_id" = "Z091498820ZZ8LGYBG1VW"
      },
    ]
    "id" = "vpce-0eea94c8bb5fd11c5"
    "network_interface_ids" = [
      "eni-00d20345c2aa71497",
      "eni-0c4a2afa126c21149",
    ]
    "owner_id" = "120357612572"
    "policy" = "{\"Statement\":[{\"Action\":\"*\",\"Effect\":\"Allow\",\"Principal\":\"*\",\"Resource\":\"*\"}]}"
    "private_dns_enabled" = true
    "requester_managed" = false
    "route_table_ids" = []
    "security_group_ids" = [
      "sg-04fd55d1e6c4d8706",
    ]
    "service_name" = "com.amazonaws.us-east-1.logs"
    "state" = "available"
    "subnet_ids" = [
      "subnet-0cf35ab1f22c912a4",
      "subnet-0eafa2ee962c64211",
    ]
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-logs-endpoint"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_endpoint_type" = "Interface"
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
  {
    "cidr_blocks" = []
    "dns_entry" = [
      {
        "dns_name" = "vpce-0a8c64a9694a3cab5-rf1bhju3.monitoring.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "vpce-0a8c64a9694a3cab5-rf1bhju3-us-east-1b.monitoring.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "vpce-0a8c64a9694a3cab5-rf1bhju3-us-east-1a.monitoring.us-east-1.vpce.amazonaws.com"
        "hosted_zone_id" = "Z7HUB22UULQXV"
      },
      {
        "dns_name" = "monitoring.us-east-1.amazonaws.com"
        "hosted_zone_id" = "Z091530143C0E1OJIXOZ"
      },
    ]
    "id" = "vpce-0a8c64a9694a3cab5"
    "network_interface_ids" = [
      "eni-072615243198d6a74",
      "eni-0d4f8e83de3b95657",
    ]
    "owner_id" = "120357612572"
    "policy" = "{\"Statement\":[{\"Action\":\"*\",\"Effect\":\"Allow\",\"Principal\":\"*\",\"Resource\":\"*\"}]}"
    "private_dns_enabled" = true
    "requester_managed" = false
    "route_table_ids" = []
    "security_group_ids" = [
      "sg-04fd55d1e6c4d8706",
    ]
    "service_name" = "com.amazonaws.us-east-1.monitoring"
    "state" = "available"
    "subnet_ids" = [
      "subnet-0cf35ab1f22c912a4",
      "subnet-0eafa2ee962c64211",
    ]
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-monitoring-endpoint"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_endpoint_type" = "Interface"
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
]
release_id = golden-vpcc4ae70e84b179d4a
security_group_id = sg-04fd55d1e6c4d8706
subnets = [
  {
    "arn" = "arn:aws:ec2:us-east-1:120357612572:subnet/subnet-0eafa2ee962c64211"
    "assign_ipv6_address_on_creation" = false
    "availability_zone" = "us-east-1a"
    "availability_zone_id" = "use1-az6"
    "cidr_block" = "172.22.0.0/18"
    "id" = "subnet-0eafa2ee962c64211"
    "ipv6_cidr_block" = null
    "ipv6_cidr_block_association_id" = ""
    "map_public_ip_on_launch" = false
    "owner_id" = "120357612572"
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-cigna-golden-subnet-001"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
  {
    "arn" = "arn:aws:ec2:us-east-1:120357612572:subnet/subnet-0cf35ab1f22c912a4"
    "assign_ipv6_address_on_creation" = false
    "availability_zone" = "us-east-1b"
    "availability_zone_id" = "use1-az1"
    "cidr_block" = "172.22.64.0/18"
    "id" = "subnet-0cf35ab1f22c912a4"
    "ipv6_cidr_block" = null
    "ipv6_cidr_block_association_id" = ""
    "map_public_ip_on_launch" = false
    "owner_id" = "120357612572"
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-cigna-golden-subnet-002"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
  {
    "arn" = "arn:aws:ec2:us-east-1:120357612572:subnet/subnet-027890397fd3791ef"
    "assign_ipv6_address_on_creation" = false
    "availability_zone" = "us-east-1c"
    "availability_zone_id" = "use1-az2"
    "cidr_block" = "172.22.128.0/18"
    "id" = "subnet-027890397fd3791ef"
    "ipv6_cidr_block" = null
    "ipv6_cidr_block_association_id" = ""
    "map_public_ip_on_launch" = false
    "owner_id" = "120357612572"
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-cigna-golden-subnet-003"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
  {
    "arn" = "arn:aws:ec2:us-east-1:120357612572:subnet/subnet-0a0b7eb3e77613a7b"
    "assign_ipv6_address_on_creation" = false
    "availability_zone" = "us-east-1d"
    "availability_zone_id" = "use1-az4"
    "cidr_block" = "172.22.192.0/18"
    "id" = "subnet-0a0b7eb3e77613a7b"
    "ipv6_cidr_block" = null
    "ipv6_cidr_block_association_id" = ""
    "map_public_ip_on_launch" = false
    "owner_id" = "120357612572"
    "tags" = {
      "AppName" = "VPC"
      "AsaqId" = "ASA-01234"
      "AssetName" = "NA"
      "AssetOwner" = "Rich Kettleman"
      "BackupOwner" = "None"
      "CiId" = "01234"
      "CostCenter" = "CA1"
      "Environment" = "Dev"
      "Name" = "DO-NOT-USE-cigna-golden-subnet-004"
      "Purpose" = "VPC"
      "Version" = "1.2.0"
    }
    "vpc_id" = "vpc-00d6e134a047071f7"
  },
]
vpc = {
  "arn" = "arn:aws:ec2:us-east-1:120357612572:vpc/vpc-00d6e134a047071f7"
  "assign_generated_ipv6_cidr_block" = false
  "cidr_block" = "172.22.0.0/16"
  "default_network_acl_id" = "acl-0d8aed51b1bd51d29"
  "default_route_table_id" = "rtb-0dbbc61053fb1b05b"
  "default_security_group_id" = "sg-06ec4cbbe41ca46aa"
  "dhcp_options_id" = "dopt-ad120dd5"
  "enable_classiclink" = false
  "enable_classiclink_dns_support" = false
  "enable_dns_hostnames" = true
  "enable_dns_support" = true
  "id" = "vpc-00d6e134a047071f7"
  "instance_tenancy" = "default"
  "ipv6_association_id" = ""
  "ipv6_cidr_block" = null
  "main_route_table_id" = "rtb-0dbbc61053fb1b05b"
  "owner_id" = "120357612572"
  "tags" = {
    "AppName" = "VPC"
    "AsaqId" = "ASA-01234"
    "AssetName" = "NA"
    "AssetOwner" = "Rich Kettleman"
    "BackupOwner" = "None"
    "CiId" = "01234"
    "CostCenter" = "CA1"
    "Environment" = "Dev"
    "Name" = "DO-NOT-USE-cigna-golden-vpc"
    "Purpose" = "VPC"
    "Version" = "1.2.0"
  }
}
```
