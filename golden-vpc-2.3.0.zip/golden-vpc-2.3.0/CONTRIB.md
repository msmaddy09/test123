# Contributing
If there are issues or feature requests you like to see in the golden-vpc you can contribute in one of two ways.
1. Formally open up a request [here](https://git.sys.cigna.com/cigna-terraform/aws/golden-vpc/issues)
2. If you prefer to work on the changes contact *Richard Kettleman* or *Noah Sutter* (details below) to setup a meeting.  
   * Once the proposed change has been reviewed and approved create a new branch off of [develop](https://git.sys.cigna.com/cigna-terraform/aws/golden-vpc/tree/develop)
   * When all the work is done create a [merge request](https://git.sys.cigna.com/cigna-terraform/aws/golden-vpc/merge_requests).  If all looks good the request will be merged into develop and a new tag will be cut to use.

## Contact Information
* **Noah Sutter** - Cloud Architect - Noah.Sutter@Cigna.com
* **Richard Kettleman** - Cloud Engineer - richard.kettleman@cigna.com

## General Inquiries
For general questions about Terraform or networking information visit these Matter Most channels:
* [Terraform](https://mm.sys.cigna.com/cloud-ops-guild/channels/terraform)
* [AWS Networking](https://mm.sys.cigna.com/cloud-ops-guild/channels/networking)