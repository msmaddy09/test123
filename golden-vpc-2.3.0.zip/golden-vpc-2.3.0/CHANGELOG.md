# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.3.0] 2023-01-05
- Adds a resolver rule association for the `openshift.evernorthcloud.com` resolver rule

## [2.2.2] 2022-10-27
- Fixes a bug where the module was using _all_ subnets within a VPC, instead of only subnets created by the module. This was causing issues for consumers who create subnets outside of the module.

## [2.2.1] 2022-10-19
- Fixes a bug that was causing errors when accessing an optional field in an object type variable

## [2.2.0] 2022-06-23
- Adds multi-region support by removing the hard-coded us-east-1 values and instead pulling them from SSM parameter store

## [2.1.0] 2022-05-19
- Upgrade AWS required provider version to allow 4.0

## [2.0.1] 2022-03-31
- Fixes a bug where we were still referencing the old central logging SSM parameters in the module outputs

## [2.0.0] 2022-03-25
- Added DNS Resolver rules for Medco.com and accounts.root.corp, respectfully.
- Changed the logging destination arn for VPC Flowlogs to point to the new "Org" ARN.
- Updated tags to be compliant with the new 2.0 standard.

## [1.9.4] 2022-03-22
- Remove Cigna branding

## [1.9.3] 2022-02-26
- Fixed an issue in local variables that accidentally required var.vpc_config.number_of_custom_subnets

## [1.9.2] 2022-02-24
- Removed localhost egress rule as AWS indicates that the existance of this rule can cause problems with api gw.
- Added egress rules for default sg to on-prem (cigna and esi)
- Added egress rule to default sg to non-routable ips

## [1.9.1] 2022-02-01
- Reverted the required terraform version to the earliest 12.x version, 0.12.31.  
- TF 0.15.0 is not required to run this module unless implementing Private NAT Gateways.  
- Added code comment describing how eks_vpc_cidrs is set.  

## [1.9.0] 2022-01-18
- Updated required terraform version to 0.15.0 and aws version to 3.67
- Added use_consolidated_custom_cidrs flag in eks_config to allow existing versions of golden-vpc to upgrade without changes to VPC CIDRs when set to false

## [1.8.3] 2021-11-17
- Added support for express-scripts.com, express-scripts.io, and us-east-1.aws.privatelink.snowflakecomputing.com domains.

## [1.8.2] 2021-07-19
- Added support for NAT Gateway
- Fixed VPC Secondary CIDR Association for RFC 6598 CIDRs
- Fixed VPC Endpoint subnet association
- Added support to delete secondary RFC 1918 VPC CIDRs

## [1.8.1] 2021-09-07
- Fix for using interface endpoints only in non-pod subnets when use_pod_subnets_for_endpoints is false
- Added tag to distinguish pod vs non-pod subnets

## [1.8.0] 2021-08-17
- Added explicit associations between the default route table and EKS node subnets ("golden" subnets) to enable Windows-specific VPC resource controller to assign IP addresses to Windows pods.

## [1.7.9] 2021-07-16
- Added support Evernorthcloud Private Hosted Zones.
- Added Support for Evernorthcloud DNS Resolver Rule.

## [1.7.8] 2021-03-01
- Added support for DNS Query Logging.
- Removed default VPC Interface Endpoint entries as a cost savings measure.
- Added support for Health Services Accounts. This removes some logic to create the Account Name from the Alias and resolves the data from the ```/Enterprise/AccountName``` Parameter Store value instead.
- Added required version for the AWS Terraform Provider. Current Terraform Module not usable with versions below 3.10.

## [1.7.7] 2021-03-01
- using endpoint service to lookup appropriate subnet ids
- ability to make the aws_subnet_ids and then to grab only the subnet ids that work with the given interface and aws service.

## [1.7.6] 2021-03-01
- Moving version tag to its own variable to avoid having it overwritten by the passed in values in `cigna_tags`

## [1.7.5] 2021-01-29
- Added fix and a script to run to fix resolver associations.

## [1.7.4] 2020-10-18
- Fixed transit gateway vpc attachment to pick 1 subnet per AZ when there are multiple
subnets per AZ. Transit gateway requires that only one subnet is specified per AZ to
enable traffic to reach resources in every subnet in that AZ.

## [1.7.3] 2020-10-09
- Took away flag that prevents Gateway endpoints to be updated when the policy changes.
- Made all pod subnets explicit route association to the pod routing table.

## [1.7.2]: 2020-10-05
- Added an boolean option custom_cidr_association.  This is to fix a breaking upgrade when using a version prior to 1.6.x.

## [1.7.1]: 2020-09-22
- Moving away from transit gateway id static mapping to using the values in parameter store.  Also added an option to specify as a variable the transit gateway id (this option is not recommended and is available for special use cases only).  
- Ability to create VPC endpoints in pod subnets if explicitly specified via EKS config. Moving existing endpoints from golden to pod subnets will likely cause temporary disruption for couple of minutes and might require update to security group if pod subnets were not included previously.

## [1.6.1]: 2020-08-19

- VPC Flow logs enabled by default, according to policy.

## [1.6]: 2020-07-22

- Took away restriction on # of subnets associated with a VPC Endpoint.  Now all primary subnets will be associated to the Endpoint.
- Decouple primary and pod subnet creation where you can specify a different number of subnets for the primary and the pod network.  Pod subnet defaults to the number of primary subnets specified.
- Remove legacy check for domain variable being set in DHCP options.
- Updated Readme

## [1.5]: 2020-06-08

- Added support for Centralized Logging Parameter Store Value. This is now a hard requirement for using Golden-VPC on New Accounts Accounts made after June of 2020.

## [1.4.4]: 2020-04-17

- Introduced control of the default Network ACL into Terraform, allowing tagging. Also added extra output values.

## [1.4.3]: 2020-04-09

- Add VPC Endpoint routes to pod subnets route table

## [1.4.2]: 2020-03-23

- Restrict the Security Group used for endpoints to only allow port 443
- Updated Readme
- Added Changelog

## [1.4.1]: 2020-02-22

- Added the variable `profile` for AWS authentication.
- Replaced name to the proper variable `name_prefix` in examples/main/vpc.auto.tfvars

## [1.4.0]: 2020-01-22

- Added support for new outbound rule to allow resolution of openshift.cignacloud.com from resources within the AWS VPC 

## [1.3.1]

- Fixed issue with transit gateway failing due to no cigna-test feield being defined in the list of Transit Gateway IDs

## [1.3.0]

- Added variable `disable_resolver_rule_association` that defaults to true
  - Rule allows attachment to shared outbound resolvers to resolve cigna on prem
  - Certain accounts do not have these rules shared and will fail if not set to false
- Fixed syntax error `failed_sdbx_tgw` check
- `tf fmt -recursive` was ran to make the code neater

## [1.2.0]

- Added support to use Dev Transit Gateway for ESI accounts
- Allow option to add policy for gateway endpoints
- Updated tagging to match current Cigna standards
- Removed custom code that calculates version of golden-vpc module being used

## [1.1.0]

- Updated examples file to reference current tag

## [1.0.0]

- Initial supported release of Golden VPC
