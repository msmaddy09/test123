# General AWS Terraform Repository

This repository sets up the general file structure for a terraform project. As an example, the project shows the terraform to create a S3 bucket using the Cigna 'golden' module. That module can be found at https://github.sys.cigna.com/cigna/terraform-aws-s3?ref=4.0.2